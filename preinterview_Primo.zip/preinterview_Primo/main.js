exports._merge = ( collection_1 ,  collection_2)=>{
    let temp_arr = [];
    let i = 0,j = 0;
    while(i < collection_1.length && j < collection_2.length){
        if(collection_1[i] < collection_2[j]){
            temp_arr.push(collection_1[i]);
            i++;
        }
        else{
            temp_arr.push(collection_2[j]);
            j++;
        }
    }
    while(i < collection_1.length){
        temp_arr.push(collection_1[i]);
        i++;
    }

    while(j < collection_2.length){
        temp_arr.push(collection_2[j]);
        j++;
    }

    return temp_arr;
}