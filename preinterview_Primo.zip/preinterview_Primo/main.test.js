const {_merge} = require('./main');

test('case 1', () => {
    var arr1 = [1,2,3,4];
    var arr2 = [5,6,7,8];
    var correct_output = [1,2,3,4,5,6,7,8];
    var output = _merge(arr1,arr2);
    expect(output).toStrictEqual(correct_output);
});

test('case 2', () => {
    var arr1 = [1,3,5,7];
    var arr2 = [2,4,6,8];
    var correct_output = [1,2,3,4,5,6,7,8];
    var output = _merge(arr1,arr2);
    expect(output).toStrictEqual(correct_output);
});

test('case 3', () => {
    var arr1 = [];
    var arr2 = [2,4,6,8];
    var correct_output = [2,4,6,8];
    var output = _merge(arr1,arr2);
    expect(output).toStrictEqual(correct_output);
});

test('case 4', () => {
    var arr1 = [1,3,5,7];
    var arr2 = [];
    var correct_output = [1,3,5,7];
    var output = _merge(arr1,arr2);
    expect(output).toStrictEqual(correct_output);
});

test('case 5', () => {
    var arr1 = [];
    var arr2 = [];
    var correct_output = [];
    var output = _merge(arr1,arr2);
    expect(output).toStrictEqual(correct_output);
});